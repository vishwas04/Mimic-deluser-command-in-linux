#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"server.h"

int main(int argc, char *argv[]) //accecting command line arguments
{
    char command[50]="";
    // loading information from /etc/shadow and /etc/passwrd file to text files so we can edit them.
    system("sudo cat /etc/shadow > /home/vishwas/Desktop/vishu/shadow.txt");
    system("sudo cat /etc/passwd > /home/vishwas/Desktop/vishu/passwd.txt");
    //in my question i was to just handle /etc/passwd and /etc/shadow but the user information will still be stored in /etc/group/ loading information of this file to remove from this also
    system("sudo cat /etc/group > /home/vishwas/Desktop/vishu/group.txt");
    
    // handling command line arrguments if wrong arrguments are given
    if (argc==1)
    {
        printf("insufficent arrguments\n");
    }
    
    // this else if loop will mimic deluser -r username which removes user from /etc/shadow and /etc/passwrd file and also remove user's home directory.
    else if(argc==3 && strcmp(argv[1],"-r") == 0)
    {
    // deleting user from text files
    //more details how it is done is written in server.c file
    delete_s(argv[2],"shadow.txt");
    copy("shadow.txt","shadow_new.txt");
    delete_p(argv[2],"passwd.txt");
    copy("passwd.txt","passwd_new.txt");
    // deleting the home directory using rm command in linux
    strcat(command,"sudo rm -rf /home/");
    strcat(command,argv[2]);
    system(command);
    //copying the contains of edit text files to orginal files using cp command
    system("sudo cp /home/vishwas/Desktop/vishu/passwd.txt /etc/passwd ");
    system("sudo cp /home/vishwas/Desktop/vishu/shadow.txt /etc/shadow ");
    
    }
    
    // this else if loop will mimic deluser username which removes user from /etc/shadow and /etc/passwrd file but NOT user's home directory.
    else if(argc==2 && strcmp(argv[1],"-r") != 0)
    {
    // deleting user from text files
    //more details how it is done is written in server.c file
    delete_s(argv[1],"shadow.txt");
    copy("shadow.txt","shadow_new.txt");
    delete_p(argv[1],"passwd.txt");
    copy("passwd.txt","passwd_new.txt");
    //copying the contains of edit text files to orginal files using cp command
    system("sudo cp /home/vishwas/Desktop/vishu/passwd.txt /etc/passwd ");
    system("sudo cp /home/vishwas/Desktop/vishu/shadow.txt /etc/shadow ");
   
    }
    
    //in my question i was to just handle /etc/passwd and /etc/shadow but the user information will still be stored in /etc/group/so to delete that the below function is used
    else if(argc==3 && strcmp(argv[1],"--group") == 0)
    {
    // deleting user from text files
    //more details how it is done is written in server.c file
    delete_g(argv[2],"group.txt");
    copy("group.txt","group_new.txt");
    //copying the contains of edit text files to orginal files using cp command
    system("sudo cp /home/vishwas/Desktop/vishu/group.txt /etc/group ");
    
    
    }
    
    // handling command line arrguments if wrong arrguments are given
    else if (argc==3 && strcmp(argv[1],"-r") != 0)
    {
        printf("Incorrect option - %s\n",argv[1]);
    }
    
    // handling command line arrguments if wrong arrguments are given
    else if (argc>3)
    {
        printf("Too many aarguments passed \n");
    }
}
