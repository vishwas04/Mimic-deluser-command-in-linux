#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"server.h"

// THIS FILE LOOKS BIG BECAUSE ALMOST SAME FUNCTION IS WRITTEN THRICE delete_s delete_p and delete_g ARE SAME I TRIED TO DO IN ONE FUCTION BUT GOT ERRORS LIKE BUS ERROR AND SEGMENTATION(CORE DUMP ERROR) .SO THIS FILE LOOKS BIG.

// this fuction is for finding whether two strings str1 and str2 are same
//it returns 1 if both are not same
//it returns 0 if both are same
int mystrcmp(char * str1,char * str2,int len)
{
    int q=0;
    for (int i=0; i<len; i++)
    {
        if (str1[i]!=str2[i])
        {
            q=1;
            return 1;
            
        }
        
    }
    
    return 0;
}

// This function is to delete the line which contains username in /etc/shadow file
//in /etc/shadow each line starts with username: 


void delete_s(char username[100],char filename[100])
{
    // this is to find how many lines are there in text file (filename)
    char ch;
    int lines=0;
    FILE * fp1;
    fp1=fopen("shadow.txt","r");
    ch=fgetc(fp1);
    while (ch!= EOF)
    {
        if (ch=='\n')
        {lines=lines+1;}
        ch=fgetc(fp1);

    }
    fclose(fp1);

    //now i have loaded all the data in text file to array buffer
    char str[400];
    char buffer[400][400];
    FILE *fp;
    fp = fopen("shadow.txt","r");
    char c;
    // load empty elements in array with '#' just to avoid to remove garbage values in empty elements 
    for (int i=0; i<400; i++)
    {
        for (int j=0; j<400; j++)
        {
            buffer[i][j]='#';
        }
    }
    int i=0;
    // loding of data takes place here
    while( fgets(str, 400, fp) != NULL )
       {

           strcpy(buffer[i],str);
           i++;
       }
    int username_len=0;
// finding length of username
    char temp_username[400][400];
    for (; username[username_len]!=0; username_len++){}

    FILE * fp_new;
    fp_new=fopen("shadow_new.txt","w");
    int j=0;
    // finding out the line which contains username information
    for (int x=0; x<lines+1 && buffer[x][0] != '#'; x++)
    {
        for (int j=0; buffer[x][j] != ':' ; j++)
        {
            temp_username[x][j]=buffer[x][j];
            temp_username[x][j+1]='\0';
        }
	//transfering all data to a new text file called shadow_new.txt except the line which contents username information 
        if (mystrcmp(temp_username[x],username,username_len) != 0)
        {
            fprintf(fp_new,"%s",buffer[x]);
        }
    }
    
    fclose(fp);
    fclose(fp_new);
    
}

// this fuction does the same fuction as delete_s but not for /etc/shadow file but for /etc/passwd file.
void delete_p(char username[100],char filename[100])
{
    char ch;
    int lines=0;
    FILE * fp1;
    
    fp1=fopen("passwd.txt","r");
    ch=fgetc(fp1);
    while (ch!= EOF)
    {
        if (ch=='\n')
        {lines=lines+1;}
        ch=fgetc(fp1);

    }
    fclose(fp1);

    
    char str[400];
    char buffer[400][400];
    FILE *fp;
    fp = fopen("passwd.txt","r");
    char c;
    
    
    for (int i=0; i<400; i++)
    {
        for (int j=0; j<400; j++)
        {
            buffer[i][j]='#';
        }
    }
    int i=0;
    
    while( fgets(str, 400, fp) != NULL )
       {

           strcpy(buffer[i],str);
           i++;
       }
    int username_len=0;

    char temp_username[400][400];
    for (; username[username_len]!=0; username_len++){}

    FILE * fp_new;
    fp_new=fopen("passwd_new.txt","w");
    int j=0;
    for (int x=0; x<lines+1 && buffer[x][0] != '#'; x++)
    {
        for (int j=0; buffer[x][j] != ':' ; j++)
        {
            temp_username[x][j]=buffer[x][j];
            temp_username[x][j+1]='\0';
        }
        
        if (mystrcmp(temp_username[x],username,username_len) != 0)
        {
            fprintf(fp_new,"%s",buffer[x]);
        }
    }
    
    fclose(fp);
    fclose(fp_new);
    
}

// this fuction does the same fuction as delete_s but not for /etc/shadow file but for /etc/group file.
void delete_g(char username[100],char filename[100])
{
    char ch;
    int lines=0;
    FILE * fp1;
    
    fp1=fopen("group.txt","r");
    ch=fgetc(fp1);
    while (ch!= EOF)
    {
        if (ch=='\n')
        {lines=lines+1;}
        ch=fgetc(fp1);

    }
    fclose(fp1);

    
    char str[400];
    char buffer[400][400];
    FILE *fp;
    fp = fopen("group.txt","r");
    char c;
    
    
    for (int i=0; i<400; i++)
    {
        for (int j=0; j<400; j++)
        {
            buffer[i][j]='#';
        }
    }
    int i=0;
    
    while( fgets(str, 400, fp) != NULL )
       {

           strcpy(buffer[i],str);
           i++;
       }
    int username_len=0;

    char temp_username[400][400];
    for (; username[username_len]!=0; username_len++){}

    FILE * fp_new;
    fp_new=fopen("group_new.txt","w");
    int j=0;
    for (int x=0; x<lines+1 && buffer[x][0] != '#'; x++)
    {
        for (int j=0; buffer[x][j] != ':' ; j++)
        {
            temp_username[x][j]=buffer[x][j];
            temp_username[x][j+1]='\0';
        }
        
        if (mystrcmp(temp_username[x],username,username_len) != 0)
        {
            fprintf(fp_new,"%s",buffer[x]);
        }
    }
    
    fclose(fp);
    fclose(fp_new);
    
}


// this fuction is to copy contains of source_filename to destination_filename
// this is used to copy shadow_new.txt(username information is deleted) to shadow.txt file 
// this is used to copy passwd_new.txt(username information is deleted) to passwd.txt file 
//then in client.c i have copied the data from shadow.txt and passwd.txt to orginal /etc/shadow and /etc/passwd files.
void copy(char destination_filename[100],char source_filename[100])
{
    FILE * source;
    FILE * destination;
    char str[400];
    source=fopen(source_filename,"r");
    destination=fopen(destination_filename,"w");
    
    while( fgets(str, 400, source) != NULL )
           {
               fprintf(destination,"%s",str);
           }
    fclose(source);
    fclose(destination);
    
    
}
