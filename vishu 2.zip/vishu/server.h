int mystrcmp(char * ,char * ,int );
void delete_s(char *,char *); //to delete user from shadow.txt file
void delete_p(char *,char *); //to delete user from passwd.txt file
void delete_g(char *,char *); //to delete user from group.txt file
void copy(char *,char *);
